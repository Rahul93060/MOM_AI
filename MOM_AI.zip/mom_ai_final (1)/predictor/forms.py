from django import forms
from .models import Patient

class PatientForm(forms.ModelForm):
    class Meta:
        model = Patient
        fields = [
            'name',
            'age',
            'systolic_bp',
            'diastolic_bp',
            'bs',
            'body_temp',
            'heart_rate'
        ]

        widgets = {
            'name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter Patient Name',
                'required': True
            }),

            'age': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Age (15-50)',
                'min': 15,
                'max': 50,
                'required': True
            }),

            'systolic_bp': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Systolic BP (80-200)',
                'min': 80,
                'max': 200,
                'required': True
            }),

            'diastolic_bp': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Diastolic BP (50-120)',
                'min': 50,
                'max': 120,
                'required': True
            }),

            'bs': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Blood Sugar (50-400)',
                'step': '0.1',
                'min': 50,
                'max': 400,
                'required': True
            }),

            'body_temp': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Body Temp (95-105 °F)',
                'step': '0.1',
                'min': 95,
                'max': 105,
                'required': True
            }),

            'heart_rate': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Heart Rate (40-180)',
                'min': 40,
                'max': 180,
                'required': True
            }),
        }
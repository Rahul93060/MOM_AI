from django.db import models

class Patient(models.Model):
    name = models.CharField(max_length=100)
    age = models.IntegerField()
    systolic_bp = models.IntegerField(verbose_name="Systolic BP")
    diastolic_bp = models.IntegerField(verbose_name="Diastolic BP")
    bs = models.FloatField(verbose_name="Blood Sugar")
    body_temp = models.FloatField(verbose_name="Body Temp")
    heart_rate = models.IntegerField()
    predicted_risk = models.CharField(max_length=50, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.name} - {self.predicted_risk}"

from django.contrib import admin
from .models import Patient

@admin.register(Patient)
class PatientAdmin(admin.ModelAdmin):
    list_display = ('name', 'age', 'predicted_risk', 'created_at')
    search_fields = ('name',)
    list_filter = ('predicted_risk', 'created_at')

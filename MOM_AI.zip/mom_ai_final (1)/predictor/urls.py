from django.urls import path
from . import views

app_name = 'predictor'

urlpatterns = [
    path('', views.home, name='home'),
    path('predict/', views.predict, name='predict'),
    path('records/', views.patient_list, name='patient_list'),
    path('api/predict/', views.predict_api, name='predict_api'),
]

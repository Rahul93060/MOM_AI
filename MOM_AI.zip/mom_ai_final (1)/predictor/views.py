import pickle
import numpy as np
import os
from django.shortcuts import render, redirect
from django.http import JsonResponse
from .forms import PatientForm
from .models import Patient
from django.db.models import Count
from django.db.models import Avg


BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ML_DIR = os.path.join(BASE_DIR, "ml_model")
model_path = os.path.join(ML_DIR, "mom_ai_model.pkl")
encoder_path = os.path.join(ML_DIR, "label_encoder.pkl")


with open(model_path, "rb") as f:
    model = pickle.load(f)
with open(encoder_path, "rb") as f:
    encoder = pickle.load(f)

def home(request):
    return render(request, "predictor/home.html")

def predict(request):
    if request.method == "POST":
        form = PatientForm(request.POST)
        if form.is_valid():
            patient = form.save(commit=False)
            
            
            data = np.array([[
                patient.age,
                patient.systolic_bp,
                patient.diastolic_bp,
                patient.bs,
                patient.body_temp,
                patient.heart_rate
            ]])
            
            
            prediction = model.predict(data)
            patient.predicted_risk = encoder.inverse_transform(prediction)[0]
            patient.save()
            
            return render(request, "predictor/result.html", {
                "risk": patient.predicted_risk,
                "patient": patient
            })
    else:
        form = PatientForm()
    
    return render(request, "predictor/form.html", {"form": form})

def patient_list(request):
    patients = Patient.objects.all().order_by('-created_at')
    return render(request, "predictor/patient_list.html", {"patients": patients})

def predict_api(request):
    try:
        age = float(request.GET.get("age", 0))
        sbp = float(request.GET.get("systolic_bp", 0))
        dbp = float(request.GET.get("diastolic_bp", 0))
        bs = float(request.GET.get("bs", 0))
        temp = float(request.GET.get("body_temp", 0))
        hr = float(request.GET.get("heart_rate", 0))
        
        data = np.array([[age, sbp, dbp, bs, temp, hr]])
        prediction = model.predict(data)
        risk = encoder.inverse_transform(prediction)[0]
        
        return JsonResponse({"status": "success", "risk": risk})
    except Exception as e:
        return JsonResponse({"status": "error", "message": str(e)}, status=400)

def all_patients_report(request):
    patients = Patient.objects.all().values()
    return JsonResponse(list(patients), safe=False)
def high_risk_report(request):
    patients = Patient.objects.filter(risk="High Risk").values()
    return JsonResponse(list(patients), safe=False)

def risk_summary_report(request):
    summary = Patient.objects.values('risk').annotate(total=Count('id'))
    return JsonResponse(list(summary), safe=False)
def date_wise_report(request):
    date = request.GET.get("date")
    patients = Patient.objects.filter(created_at__date=date).values()
    return JsonResponse(list(patients), safe=False)


def statistics_report(request):
    data = {
        "total_patients": Patient.objects.count(),
        "avg_age": Patient.objects.aggregate(Avg("age"))["age__avg"],
        "high_risk_count": Patient.objects.filter(risk="High Risk").count(),
        "low_risk_count": Patient.objects.filter(risk="Low Risk").count(),
    }
    return JsonResponse(data)